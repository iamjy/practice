#include <linux/module.h>
#include <linux/vermagic.h>
#include <linux/compiler.h>

MODULE_INFO(vermagic, VERMAGIC_STRING);

struct module __this_module
__attribute__((section(".gnu.linkonce.this_module"))) = {
 .name = KBUILD_MODNAME,
 .init = init_module,
#ifdef CONFIG_MODULE_UNLOAD
 .exit = cleanup_module,
#endif
 .arch = MODULE_ARCH_INIT,
};

static const struct modversion_info ____versions[]
__used
__attribute__((section("__versions"))) = {
	{ 0xc7087dc4, "module_layout" },
	{ 0x472904f9, "video_ioctl2" },
	{ 0xb087e899, "video_device_release" },
	{ 0x17581d53, "__video_register_device" },
	{ 0x12f6ceb4, "dev_set_drvdata" },
	{ 0x2b5cdfdb, "video_device_alloc" },
	{ 0xf0fdf6cb, "__stack_chk_fail" },
	{ 0x4f8b5ddb, "_copy_to_user" },
	{ 0x4f6b400b, "_copy_from_user" },
	{ 0xa0d05224, "module_refcount" },
	{ 0x27e1a049, "printk" },
	{ 0xb4390f9a, "mcount" },
};

static const char __module_depends[]
__used
__attribute__((section(".modinfo"))) =
"depends=videodev";


MODULE_INFO(srcversion, "67BCEDC06CC36E4EBBEB8A6");
